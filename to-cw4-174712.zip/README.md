# Testowanie oprogramowania – ćwiczenia 4

Projekt zawiera rozwiązane testy Selenium i pytest z ćwiczeń 4, w tym
12 par lokalizatorów CSS/XPath oraz wszystkie zadania samodzielne.
