"""Independent exercises from the end of exercise 4."""
import time

import pytest
from selenium import webdriver
from selenium.common.exceptions import ElementNotInteractableException
from selenium.webdriver.common.by import By
from selenium.webdriver.support.relative_locator import locate_with

from config import INTERNET_URL, SELENIUM_WEB_URL
from helpers import open_page
from test_checkboxes import CHECKBOXES
from test_login import log_in


def test_wrong_username_and_password_message(driver):
    """An invalid username is reported before the password is checked."""
    flash = log_in(driver, "wrong-user", "wrong-password")
    assert "Your username is invalid!" in flash.text


def test_check_only_unchecked_boxes(driver):
    open_page(driver, f"{INTERNET_URL}/checkboxes", By.ID, "checkboxes")
    boxes = driver.find_elements(*CHECKBOXES)
    for box in boxes:
        if not box.is_selected():
            box.click()
    assert all(box.is_selected() for box in boxes)


def test_range_default_value(driver):
    open_page(
        driver,
        f"{SELENIUM_WEB_URL}/web-form.html",
        By.TAG_NAME,
        "form",
    )
    slider = driver.find_element(By.NAME, "my-range")
    assert slider.get_property("value") == "5"


def test_submit_button_text_color(driver):
    open_page(
        driver,
        f"{SELENIUM_WEB_URL}/web-form.html",
        By.TAG_NAME,
        "form",
    )
    button = driver.find_element(By.CSS_SELECTOR, "form button")
    assert button.value_of_css_property("color") == "rgba(13, 110, 253, 1)"


def test_every_table1_email_contains_at_sign(driver):
    open_page(driver, f"{INTERNET_URL}/tables", By.ID, "table1")
    emails = driver.find_elements(
        By.CSS_SELECTOR,
        "#table1 tbody td:nth-child(3)",
    )
    assert emails
    assert all("@" in email.text for email in emails)


def test_password_is_below_username(driver):
    open_page(driver, f"{INTERNET_URL}/login", By.ID, "login")
    username = driver.find_element(By.ID, "username")
    field_below = driver.find_element(
        locate_with(By.TAG_NAME, "input").below(username)
    )
    assert field_below.get_attribute("id") == "password"


@pytest.fixture(scope="module")
def module_driver():
    """One browser shared by two tests, with its total lifetime measured."""
    started = time.perf_counter()
    drv = webdriver.Chrome()
    drv.implicitly_wait(0)
    yield drv
    elapsed = time.perf_counter() - started
    print(f"\nmodule_driver lifetime: {elapsed:.2f} s")
    drv.quit()


@pytest.mark.parametrize(
    ("path", "marker"),
    [
        ("/login", (By.ID, "login")),
        ("/checkboxes", (By.ID, "checkboxes")),
    ],
)
def test_module_scoped_fixture(module_driver, path, marker):
    open_page(module_driver, f"{INTERNET_URL}{path}", *marker)
    assert module_driver.title == "The Internet"


def test_send_keys_to_disabled_field_raises(driver):
    open_page(
        driver,
        f"{SELENIUM_WEB_URL}/web-form.html",
        By.TAG_NAME,
        "form",
    )
    disabled = driver.find_element(By.NAME, "my-disabled")
    with pytest.raises(ElementNotInteractableException):
        disabled.send_keys("cannot be entered")
