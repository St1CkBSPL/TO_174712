# Odpowiedzi do zadań samodzielnych:

1. Gdy login i hasło są błędne, strona najpierw sprawdza login i zwraca
   `Your username is invalid!`.
2. Pętla zaznaczająca wyłącznie niezaznaczone checkboxy znajduje się w
   `test_check_only_unchecked_boxes`.
3. Domyślna wartość suwaka `my-range` to `5`.
4. Chrome zwraca kolor tekstu przycisku Submit jako
   `rgba(13, 110, 253, 1)`.
5. Test sprawdza, czy lista e-maili nie jest pusta i czy każdy adres zawiera
   znak `@`.
6. Lokalizator względny znajduje pole `password` poniżej pola `username`.
7. Fixture `module_driver` mierzy cały czas życia współdzielonej przeglądarki
   i wypisuje go po testach. Jest szybsza od uruchamiania Chrome dla każdego
   testu, ale niesie ryzyko przecieku stanu (URL, cookies, formularze) między
   testami; awaria jednej sesji może też zepsuć pozostałe testy modułu.
8. `send_keys` na polu disabled zgłasza
   `ElementNotInteractableException`; zachowanie sprawdza `pytest.raises`.
